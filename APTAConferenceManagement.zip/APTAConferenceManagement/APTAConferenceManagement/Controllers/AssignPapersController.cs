﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using APTAConferenceManagement.Models;

namespace APTAConferenceManagement.Controllers
{
    public class AssignPapersController : Controller
    {
        private APTAconferencemanagementEntities db = new APTAconferencemanagementEntities();

        // GET: AssignPapers
        public ActionResult Index()
        {
            var assignPapers = db.AssignPapers.Include(a => a.AspNetUser).Include(a => a.Paper);
            return View(assignPapers.ToList());
        }

        // GET: AssignPapers/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            AssignPaper assignPaper = db.AssignPapers.Find(id);
            if (assignPaper == null)
            {
                return HttpNotFound();
            }
            return View(assignPaper);
        }

        // GET: AssignPapers/Create
        public ActionResult Create()
        {
            ViewBag.ReviewerId = new SelectList(db.AspNetUsers, "Id", "Email");
            ViewBag.PaperId = new SelectList(db.Papers, "Id", "Title");
            return View();
        }

        // POST: AssignPapers/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "PaperId,ReviewerId,Id")] AssignPaper assignPaper)
        {
            if (ModelState.IsValid)
            {
                db.AssignPapers.Add(assignPaper);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.ReviewerId = new SelectList(db.AspNetUsers, "Id", "Email", assignPaper.ReviewerId);
            ViewBag.PaperId = new SelectList(db.Papers, "Id", "Title", assignPaper.PaperId);
            return View(assignPaper);
        }

        // GET: AssignPapers/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            AssignPaper assignPaper = db.AssignPapers.Find(id);
            if (assignPaper == null)
            {
                return HttpNotFound();
            }
            ViewBag.ReviewerId = new SelectList(db.AspNetUsers, "Id", "Email", assignPaper.ReviewerId);
            ViewBag.PaperId = new SelectList(db.Papers, "Id", "Title", assignPaper.PaperId);
            return View(assignPaper);
        }

        // POST: AssignPapers/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "PaperId,ReviewerId,Id")] AssignPaper assignPaper)
        {
            if (ModelState.IsValid)
            {
                db.Entry(assignPaper).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.ReviewerId = new SelectList(db.AspNetUsers, "Id", "Email", assignPaper.ReviewerId);
            ViewBag.PaperId = new SelectList(db.Papers, "Id", "Title", assignPaper.PaperId);
            return View(assignPaper);
        }

        // GET: AssignPapers/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            AssignPaper assignPaper = db.AssignPapers.Find(id);
            if (assignPaper == null)
            {
                return HttpNotFound();
            }
            return View(assignPaper);
        }

        // POST: AssignPapers/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            AssignPaper assignPaper = db.AssignPapers.Find(id);
            db.AssignPapers.Remove(assignPaper);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
